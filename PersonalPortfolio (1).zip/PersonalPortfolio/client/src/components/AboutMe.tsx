import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function AboutMe() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1, rootMargin: '0px 0px -50px 0px' }
    );

    const element = document.getElementById('about-me');
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="about-me" className="py-20" data-testid="about-section">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl font-bold text-center text-primary mb-12 relative"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          data-testid="about-title"
        >
          關於我
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-secondary rounded-full"></div>
        </motion.h2>
        
        <div className="max-w-4xl mx-auto">
          <motion.div 
            className="bg-card p-8 rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 hover:scale-[1.02] cursor-pointer"
            initial={{ opacity: 0, y: 50 }}
            animate={isVisible ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            data-testid="about-card"
          >
            <p className="text-lg leading-relaxed text-card-foreground mb-6">
              我是應屆大學畢業生，對行銷企劃充滿熱情，特別是品牌行銷與視覺設計。曾參與政府開設的職業訓練課程，累積了三個月的行銷實務與工具應用經驗。我熟悉 
              <strong className="text-primary"> Canva 設計基礎</strong>，並能運用多種 AI 工具，如 ChatGPT、Gemini、NotebookLM、X-Mind、Bing Image Creator 等，來輔助內容企劃與視覺設計。
            </p>
            <p className="text-lg leading-relaxed text-card-foreground">
              雖然目前相關經驗尚淺，但我具備高度的<strong className="text-primary">學習力與執行力</strong>，期望將所學運用於實務，為團隊帶來創意與效益。
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
