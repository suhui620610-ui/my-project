import { useEffect, useRef } from "react";

declare global {
  interface Window {
    Chart: any;
  }
}

export default function RadarChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const script = document.createElement('script');
    script.src = "https://cdn.jsdelivr.net/npm/chart.js";
    script.onload = () => {
      if (canvasRef.current && window.Chart) {
        const ctx = canvasRef.current.getContext('2d');
        if (ctx) {
          new window.Chart(ctx, {
            type: 'radar',
            data: {
              labels: ['視覺設計', 'AI應用', '數據分析', '品牌行銷', '內容企劃', '持續學習力'],
              datasets: [{
                label: '技能熟練度',
                data: [70, 90, 60, 80, 85, 100],
                backgroundColor: 'rgba(94, 139, 126, 0.2)',
                borderColor: 'rgba(94, 139, 126, 1)',
                borderWidth: 2,
                pointBackgroundColor: 'rgba(94, 139, 126, 1)',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 6
              }]
            },
            options: {
              responsive: true,
              maintainAspectRatio: true,
              plugins: {
                legend: {
                  display: false
                }
              },
              scales: {
                r: {
                  beginAtZero: true,
                  max: 100,
                  ticks: {
                    stepSize: 20,
                    font: {
                      size: 12,
                      family: 'Noto Sans TC'
                    }
                  },
                  pointLabels: {
                    font: {
                      size: 14,
                      family: 'Noto Sans TC',
                      weight: '500'
                    }
                  },
                  grid: {
                    color: 'rgba(0, 0, 0, 0.1)'
                  }
                }
              }
            }
          });
        }
      }
    };
    document.head.appendChild(script);

    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  return (
    <div className="radar-chart-container flex justify-center">
      <canvas 
        ref={canvasRef} 
        data-testid="radar-chart-canvas"
      ></canvas>
    </div>
  );
}
