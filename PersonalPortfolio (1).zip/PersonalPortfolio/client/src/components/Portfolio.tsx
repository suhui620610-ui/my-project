import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const portfolioItems = [
  {
    title: "品牌練習 | LOGO+色彩搭配",
    description: "透過自學工具，練習品牌視覺設計。",
    tools: "設計工具：Canva, PhotoPea"
  },
  {
    title: "社群貼文設計 | IG模板練習", 
    description: "結合 Canva 與 AI 工具，進行社群內容設計練習。",
    tools: "工具：ChatGPT, Canva, Analytics"
  },
  {
    title: "行銷簡報版型 | AI+Canva 製作",
    description: "運用 AI 與設計工具，製作具視覺吸引力的簡報版型。",
    tools: "工具：ChatGPT, Gemini, NotebookLM"
  },
  {
    title: "市場調研報告",
    description: "運用數據分析工具深入研究目標市場，製作詳細的競品分析與消費者洞察報告。",
    tools: "工具：X-Mind, AI 輔助分析"
  },
  {
    title: "AI 輔助創意企劃",
    description: "善用 AI 工具輔助創意發想與內容生成，提高企劃效率並創造更多元的解決方案。",
    tools: "工具：ChatGPT, Gemini, NotebookLM"
  },
  {
    title: "品牌策略提案",
    description: "結合市場調研與創意思維，為企業制定完整的品牌定位與行銷策略，包含執行時程與預算規劃。",
    tools: "核心技能：策略思維, 簡報設計"
  }
];

export default function Portfolio() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('portfolio');
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="portfolio" className="py-20" data-testid="portfolio-section">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl font-bold text-center text-primary mb-12 relative"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          data-testid="portfolio-title"
        >
          作品集
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-secondary rounded-full"></div>
        </motion.h2>
        
        <motion.div 
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {portfolioItems.map((item, index) => (
            <motion.div
              key={index}
              className="bg-card p-6 rounded-2xl shadow-lg border-l-4 border-primary hover:shadow-2xl hover:border-accent transition-all duration-300"
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ 
                y: -8,
                boxShadow: "0 20px 40px rgba(0, 0, 0, 0.15)"
              }}
              data-testid={`portfolio-item-${index}`}
            >
              <h3 className="text-xl font-bold mb-4 text-primary" data-testid={`portfolio-title-${index}`}>
                {item.title}
              </h3>
              <p className="text-muted-foreground mb-4 leading-relaxed" data-testid={`portfolio-description-${index}`}>
                {item.description}
              </p>
              <div className="text-sm text-accent font-medium" data-testid={`portfolio-tools-${index}`}>
                {item.tools}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
