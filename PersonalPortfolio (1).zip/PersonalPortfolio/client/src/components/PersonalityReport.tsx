import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function PersonalityReport() {
  const [isVisible, setIsVisible] = useState(false);
  const [expandedCards, setExpandedCards] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('personality');
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  const toggleExpand = (cardId: string) => {
    setExpandedCards(prev => ({
      ...prev,
      [cardId]: !prev[cardId]
    }));
  };

  const challenges = [
    "過度配合：傾向於照顧他人感受，可能讓我難以拒絕。",
    "不善變通：不喜歡改變，可能讓我錯失一些機會。", 
    "不主動表達：在需要果斷決策時可能較為被動。"
  ];

  const growthDirections = [
    "學習設立界線，保護自己的能量。",
    "在感覺對了的時候，嘗試新事物。",
    "在需要時，為自己勇敢發聲。"
  ];

  return (
    <section id="personality" className="py-20 bg-gradient-to-br from-primary/10 via-secondary/20 to-accent/10" data-testid="personality-section">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl font-bold text-center text-primary mb-12 relative"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          data-testid="personality-title"
        >
          人格特質報告
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-primary rounded-full"></div>
        </motion.h2>
        
        {/* Core Traits Summary */}
        <motion.div 
          className="max-w-4xl mx-auto mb-12"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <div 
            className="bg-card p-8 rounded-2xl shadow-xl text-center cursor-pointer hover:shadow-2xl hover:scale-[1.02] transition-all duration-300"
            onClick={() => toggleExpand('summary')}
            data-testid="personality-summary-card"
          >
            <h3 className="text-2xl font-bold mb-4 text-card-foreground" data-testid="personality-summary-title">
              我的核心特質
            </h3>
            <p className="text-lg text-card-foreground leading-relaxed mb-4">
              我是<strong className="text-primary">腳踏實地、溫和可靠的守護者</strong>。我擅長穩定和維護周遭的和諧，並且具備極高的同理心和責任感。
            </p>
            <motion.div 
              className="overflow-hidden"
              initial={false}
              animate={{ 
                height: expandedCards['summary'] ? 'auto' : 0,
                opacity: expandedCards['summary'] ? 1 : 0
              }}
              transition={{ duration: 0.5 }}
              data-testid="personality-summary-expanded"
            >
              <p className="text-lg text-muted-foreground leading-relaxed pt-4">
                我的內在驅動力來自於對穩定和和諧的渴望，當我遵循內心回應時，會感到特別有力量。這種特質讓我在團隊中成為不可或缺的穩定力量。
              </p>
            </motion.div>
          </div>
        </motion.div>
        
        {/* Personality Type Cards */}
        <motion.div 
          className="grid md:grid-cols-3 gap-8 mb-12"
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.4 }}
        >
          {/* ISFJ Card */}
          <motion.div 
            className="bg-card p-6 rounded-2xl shadow-lg cursor-pointer hover:shadow-xl hover:scale-[1.02] transition-all duration-300"
            onClick={() => toggleExpand('isfj')}
            whileHover={{ y: -5 }}
            data-testid="isfj-card"
          >
            <div className="flex items-center mb-4">
              <div className="w-16 h-16 bg-primary text-white rounded-full flex items-center justify-center text-xl font-bold mr-4">
                ISFJ
              </div>
              <h3 className="text-xl font-bold text-card-foreground" data-testid="isfj-title">守衛者</h3>
            </div>
            <motion.div 
              className="overflow-hidden"
              initial={false}
              animate={{ 
                height: expandedCards['isfj'] ? 'auto' : 0,
                opacity: expandedCards['isfj'] ? 1 : 0
              }}
              transition={{ duration: 0.5 }}
              data-testid="isfj-content"
            >
              <p className="text-muted-foreground leading-relaxed">
                我是一個<strong>非常可靠、有責任感</strong>的人，傾向於腳踏實地，喜歡有規律的生活。在人際關係中，我總是那個<strong>默默支持他人</strong>的守護者。
              </p>
            </motion.div>
          </motion.div>
          
          {/* DISC Card */}
          <motion.div 
            className="bg-card p-6 rounded-2xl shadow-lg cursor-pointer hover:shadow-xl hover:scale-[1.02] transition-all duration-300"
            onClick={() => toggleExpand('disc')}
            whileHover={{ y: -5 }}
            data-testid="disc-card"
          >
            <div className="flex items-center mb-4">
              <div className="w-16 h-16 bg-accent text-white rounded-full flex items-center justify-center text-xl font-bold mr-4">
                S
              </div>
              <h3 className="text-xl font-bold text-card-foreground" data-testid="disc-title">DISC：S 型</h3>
            </div>
            <motion.div 
              className="overflow-hidden"
              initial={false}
              animate={{ 
                height: expandedCards['disc'] ? 'auto' : 0,
                opacity: expandedCards['disc'] ? 1 : 0
              }}
              transition={{ duration: 0.5 }}
              data-testid="disc-content"
            >
              <p className="text-muted-foreground leading-relaxed">
                我的高 S 分數代表我<strong>溫和、有耐心且善於傾聽</strong>。我不喜歡衝突，更傾向於以合作與包容的態度來與人相處，是團隊中不可或缺的穩定力量。
              </p>
            </motion.div>
          </motion.div>
          
          {/* Human Design Card */}
          <motion.div 
            className="bg-card p-6 rounded-2xl shadow-lg cursor-pointer hover:shadow-xl hover:scale-[1.02] transition-all duration-300"
            onClick={() => toggleExpand('humandesign')}
            whileHover={{ y: -5 }}
            data-testid="humandesign-card"
          >
            <div className="flex items-center mb-4">
              <div className="w-16 h-16 bg-secondary text-primary rounded-full flex items-center justify-center text-xl font-bold mr-4">
                HD
              </div>
              <h3 className="text-xl font-bold text-card-foreground" data-testid="humandesign-title">人類圖：生產者</h3>
            </div>
            <motion.div 
              className="overflow-hidden"
              initial={false}
              animate={{ 
                height: expandedCards['humandesign'] ? 'auto' : 0,
                opacity: expandedCards['humandesign'] ? 1 : 0
              }}
              transition={{ duration: 0.5 }}
              data-testid="humandesign-content"
            >
              <p className="text-muted-foreground leading-relaxed">
                作為生產者，我的能量是<strong>持續而穩定</strong>的。我的人生策略是<strong>「等待回應」</strong>，這提醒我順應內心，當我感到有感覺時再行動，避免不必要的挫敗感。
              </p>
            </motion.div>
          </motion.div>
        </motion.div>
        
        {/* Challenges and Growth */}
        <motion.div 
          className="bg-card p-8 rounded-2xl shadow-xl max-w-4xl mx-auto"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8, delay: 0.6 }}
          data-testid="challenges-growth-card"
        >
          <h3 className="text-2xl font-bold text-center mb-8 text-card-foreground" data-testid="challenges-growth-title">
            我的挑戰與成長方向
          </h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div data-testid="challenges-section">
              <h4 className="text-xl font-semibold mb-4 text-card-foreground flex items-center">
                <motion.span 
                  className="w-3 h-3 bg-red-500 rounded-full mr-3"
                  animate={{ scale: [1, 1.1, 1], opacity: [1, 0.8, 1] }}
                  transition={{ duration: 2, repeat: Infinity }}
                />
                挑戰
              </h4>
              <ul className="space-y-3 text-muted-foreground">
                {challenges.map((challenge, index) => (
                  <motion.li 
                    key={index}
                    className="flex items-start"
                    initial={{ opacity: 0, x: -20 }}
                    animate={isVisible ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.6, delay: 0.8 + 0.1 * index }}
                    data-testid={`challenge-${index}`}
                  >
                    <span className="w-2 h-2 bg-red-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    <span dangerouslySetInnerHTML={{ __html: challenge.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                  </motion.li>
                ))}
              </ul>
            </div>
            <div data-testid="growth-section">
              <h4 className="text-xl font-semibold mb-4 text-card-foreground flex items-center">
                <motion.span 
                  className="w-3 h-3 bg-green-500 rounded-full mr-3"
                  animate={{ scale: [1, 1.1, 1], opacity: [1, 0.8, 1] }}
                  transition={{ duration: 2, repeat: Infinity, delay: 1 }}
                />
                成長方向
              </h4>
              <ul className="space-y-3 text-muted-foreground">
                {growthDirections.map((direction, index) => (
                  <motion.li 
                    key={index}
                    className="flex items-start"
                    initial={{ opacity: 0, x: 20 }}
                    animate={isVisible ? { opacity: 1, x: 0 } : {}}
                    transition={{ duration: 0.6, delay: 1.0 + 0.1 * index }}
                    data-testid={`growth-${index}`}
                  >
                    <span className="w-2 h-2 bg-green-400 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                    <span dangerouslySetInnerHTML={{ __html: direction.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                  </motion.li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
