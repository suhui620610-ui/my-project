import { motion } from "framer-motion";
import { useEffect, useState } from "react";
import RadarChart from "./RadarChart";

const skills = [
  {
    icon: "fas fa-palette",
    title: "視覺設計",
    description: "具備 Canva 基礎操作經驗。能獨立完成社群貼文與簡報設計。",
  },
  {
    icon: "fas fa-robot",
    title: "AI 應用",
    description: "熟練運用 ChatGPT、Gemini、NotebookLM 等工具進行內容創作與分析。",
  },
  {
    icon: "fas fa-chart-line",
    title: "數據分析",
    description: "運用 Google Analytics 基礎功能進行數據觀察與分析。",
  },
  {
    icon: "fas fa-bullhorn",
    title: "品牌行銷",
    description: "具備品牌定位、市場調研、行銷策略規劃的理論基礎與實務應用。",
  },
];

export default function Skills() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('skills');
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="skills" className="py-20 bg-secondary" data-testid="skills-section">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl font-bold text-center text-primary mb-12 relative"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          data-testid="skills-title"
        >
          我的技能
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-primary rounded-full"></div>
        </motion.h2>
        
        {/* Skills Grid */}
        <motion.div 
          className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16"
          initial={{ opacity: 0 }}
          animate={isVisible ? { opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          {skills.map((skill, index) => (
            <motion.div
              key={skill.title}
              className="bg-card p-6 rounded-2xl shadow-lg text-center group cursor-pointer hover:shadow-2xl transition-all duration-300"
              whileHover={{ 
                y: -8, 
                scale: 1.02,
              }}
              initial={{ opacity: 0, y: 30 }}
              animate={isVisible ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              data-testid={`skill-card-${index}`}
            >
              <motion.div 
                className="text-5xl text-primary mb-4"
                whileHover={{ rotate: 360 }}
                transition={{ duration: 0.5 }}
                data-testid={`skill-icon-${index}`}
              >
                <i className={skill.icon}></i>
              </motion.div>
              <h3 className="text-xl font-bold mb-3 text-card-foreground" data-testid={`skill-title-${index}`}>
                {skill.title}
              </h3>
              <p className="text-muted-foreground" data-testid={`skill-description-${index}`}>
                {skill.description}
              </p>
            </motion.div>
          ))}
        </motion.div>
        
        {/* Radar Chart */}
        <motion.div 
          className="bg-card p-8 rounded-2xl shadow-xl max-w-2xl mx-auto"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={isVisible ? { opacity: 1, scale: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.5 }}
          data-testid="radar-chart-container"
        >
          <h3 className="text-2xl font-bold text-center mb-6 text-card-foreground" data-testid="radar-chart-title">
            技能熟練度
          </h3>
          <RadarChart />
        </motion.div>
      </div>
    </section>
  );
}
