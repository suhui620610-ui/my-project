import { motion } from "framer-motion";

export default function Contact() {
  return (
    <section id="contact" className="py-20 bg-primary text-white" data-testid="contact-section">
      <div className="container mx-auto px-6 text-center">
        <motion.h2 
          className="text-4xl font-bold mb-8"
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          data-testid="contact-title"
        >
          聯絡我
        </motion.h2>
        <motion.p 
          className="text-xl mb-12 opacity-90"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 0.9, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
          data-testid="contact-subtitle"
        >
          歡迎與我聯繫，討論合作機會
        </motion.p>
        
        <motion.div 
          className="flex flex-col md:flex-row justify-center items-center gap-8"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
        >
          {/* Email */}
          <motion.a 
            href="mailto:mandy011004@gmail.com" 
            className="flex items-center text-xl hover:text-secondary transition-all duration-300"
            whileHover={{ y: -2 }}
            data-testid="contact-email"
          >
            <i className="fas fa-envelope mr-3 text-2xl"></i>
            mandy011004@gmail.com
          </motion.a>
          
          {/* Phone */}
          <motion.a 
            href="tel:0971-886-903" 
            className="flex items-center text-xl hover:text-secondary transition-all duration-300"
            whileHover={{ y: -2 }}
            data-testid="contact-phone"
          >
            <i className="fas fa-phone mr-3 text-2xl"></i>
            0971-886-903
          </motion.a>
          
          {/* LinkedIn */}
          <motion.a 
            href="https://linkedin.com/in/柔均" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center text-xl hover:text-secondary transition-all duration-300"
            whileHover={{ y: -2 }}
            data-testid="contact-linkedin"
          >
            <i className="fab fa-linkedin mr-3 text-2xl"></i>
            LinkedIn
          </motion.a>
        </motion.div>
        
        <motion.div 
          className="mt-12 pt-8 border-t border-white/20 text-sm opacity-70"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 0.7 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          viewport={{ once: true }}
          data-testid="contact-footer"
        >
          <p>此履歷網站展示我的專業技能與創意思維，期待與您的進一步交流。</p>
        </motion.div>
      </div>
    </section>
  );
}
