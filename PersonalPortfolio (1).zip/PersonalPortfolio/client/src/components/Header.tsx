import { motion } from "framer-motion";

export default function Header() {
  return (
    <header className="wave-bg min-h-screen flex items-center justify-center relative overflow-hidden" data-testid="header-section">
      {/* Floating geometric shapes */}
      <div className="geometric-shape w-20 h-20 bg-white rounded-full" style={{ animationDelay: '0s' }}></div>
      <div className="geometric-shape w-16 h-16 bg-white transform rotate-45" style={{ animationDelay: '2s' }}></div>
      <div className="geometric-shape w-12 h-12 bg-white rounded-full" style={{ animationDelay: '4s' }}></div>
      
      <div className="container mx-auto px-6 text-center text-white relative z-10">
        
        {/* Name sliding up from bottom */}
        <motion.h1 
          className="text-6xl md:text-8xl font-bold mb-4 tracking-wide"
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, ease: "easeOut", delay: 0.2 }}
          data-testid="header-title"
        >
          林柔均
        </motion.h1>
        
        {/* Tagline sliding up with delay */}
        <motion.p 
          className="text-2xl md:text-3xl font-light opacity-90"
          initial={{ opacity: 0, y: 100 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.5, ease: "easeOut", delay: 0.5 }}
          data-testid="header-tagline"
        >
          熱忱與創意兼具的行銷企劃人
        </motion.p>
        
        {/* Scroll indicator */}
        <motion.div 
          className="absolute bottom-10 left-1/2 transform -translate-x-1/2 animate-bounce"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 1 }}
          data-testid="scroll-indicator"
        >
          <i className="fas fa-chevron-down text-white text-2xl"></i>
        </motion.div>
      </div>
    </header>
  );
}
