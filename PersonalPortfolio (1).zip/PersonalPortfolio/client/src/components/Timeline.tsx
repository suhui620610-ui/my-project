import { motion } from "framer-motion";
import { useEffect, useState } from "react";

const timelineItems = [
  {
    date: "2021/9 - 2025/6",
    title: "東海大學 | 餐旅管理系",
    subtitle: "大學畢業",
    description: "完成學士學位，奠定紮實的理論基礎，培養批判思考與問題解決能力。",
  },
  {
    date: "2022/7 - 2022/10",
    title: "味芳國際股份有限公司",
    subtitle: "服務生 (實習+工讀)",
    description: "協助餐飲服務、為客人處理疑問，培養服務精神與溝通技巧。",
  },
  {
    date: "2025/6 - 2025/9",
    title: "政府職業訓練課程",
    subtitle: "三個月行銷實務與工具應用經驗",
    description: "專精行銷企劃與數位工具應用，累積密集的實戰訓練經驗。",
  },
  {
    date: "2025",
    title: "職涯新起點",
    subtitle: "準備投入行銷企劃領域",
    description: "期待運用所學技能為企業創造價值，開展專業行銷企劃職涯。",
  },
];

export default function Timeline() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const element = document.getElementById('timeline');
    if (element) {
      observer.observe(element);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section id="timeline" className="py-20" data-testid="timeline-section">
      <div className="container mx-auto px-6">
        <motion.h2 
          className="text-4xl font-bold text-center text-primary mb-12 relative"
          initial={{ opacity: 0, y: 50 }}
          animate={isVisible ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          data-testid="timeline-title"
        >
          學經歷時間軸
          <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-20 h-1 bg-secondary rounded-full"></div>
        </motion.h2>
        
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute top-1/2 left-8 right-8 h-1 bg-border transform -translate-y-1/2 z-0"></div>
          
          {/* Timeline container with horizontal scroll */}
          <div 
            className="flex overflow-x-auto gap-8 px-8 py-8 scroll-smooth"
            style={{
              scrollSnapType: 'x mandatory',
              scrollbarWidth: 'thin',
              scrollbarColor: 'var(--primary) var(--muted)'
            }}
            data-testid="timeline-container"
          >
            {timelineItems.map((item, index) => (
              <motion.div
                key={index}
                className="flex-shrink-0 w-80 bg-card p-6 rounded-2xl shadow-lg relative hover:shadow-xl transition-all duration-300 hover:-translate-y-3"
                style={{ scrollSnapAlign: 'center' }}
                initial={{ opacity: 0, x: 100 }}
                animate={isVisible ? { opacity: 1, x: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.1 * index }}
                whileHover={{ y: -12 }}
                data-testid={`timeline-item-${index}`}
              >
                {/* Timeline dot */}
                <div className="absolute w-4 h-4 bg-primary border-4 border-white rounded-full top-1/2 -left-6 transform -translate-y-1/2 z-10"></div>
                
                <div className="text-sm text-muted-foreground mb-2" data-testid={`timeline-date-${index}`}>
                  {item.date}
                </div>
                <h3 className="text-lg font-bold text-primary mb-2" data-testid={`timeline-title-${index}`}>
                  {item.title}
                </h3>
                <div className="text-sm font-medium text-accent mb-3" data-testid={`timeline-subtitle-${index}`}>
                  {item.subtitle}
                </div>
                <p className="text-card-foreground text-sm leading-relaxed" data-testid={`timeline-description-${index}`}>
                  {item.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
