import { useEffect } from "react";
import Header from "@/components/Header";
import AboutMe from "@/components/AboutMe";
import Skills from "@/components/Skills";
import Timeline from "@/components/Timeline";
import PersonalityReport from "@/components/PersonalityReport";
import Portfolio from "@/components/Portfolio";
import Contact from "@/components/Contact";

export default function Home() {
  useEffect(() => {
    // Set document title and meta description
    document.title = "林柔均 | 行銷企劃履歷 - 熱忱與創意兼具的行銷企劃人";
    
    const metaDescription = document.querySelector('meta[name="description"]');
    if (metaDescription) {
      metaDescription.setAttribute('content', '林柔均的動態個人作品集，展示行銷企劃專業技能、人格特質分析與創意作品。具備視覺設計、AI應用、品牌行銷等多元能力。');
    } else {
      const meta = document.createElement('meta');
      meta.name = "description";
      meta.content = "林柔均的動態個人作品集，展示行銷企劃專業技能、人格特質分析與創意作品。具備視覺設計、AI應用、品牌行銷等多元能力。";
      document.head.appendChild(meta);
    }

    // Add Open Graph tags
    const ogTitle = document.createElement('meta');
    ogTitle.setAttribute('property', 'og:title');
    ogTitle.content = '林柔均 | 行銷企劃履歷';
    document.head.appendChild(ogTitle);

    const ogDescription = document.createElement('meta');
    ogDescription.setAttribute('property', 'og:description');
    ogDescription.content = '熱忱與創意兼具的行銷企劃人，具備視覺設計、AI應用等多元技能';
    document.head.appendChild(ogDescription);

    const ogType = document.createElement('meta');
    ogType.setAttribute('property', 'og:type');
    ogType.content = 'website';
    document.head.appendChild(ogType);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <AboutMe />
      <Skills />
      <Timeline />
      <PersonalityReport />
      <Portfolio />
      <Contact />
    </div>
  );
}
